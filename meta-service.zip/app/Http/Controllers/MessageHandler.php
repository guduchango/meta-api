<?php

namespace App\Http\Controllers;
use App\Models\Appointment;
use App\Models\ChatFlow;
use App\Models\Chat;
use Illuminate\Support\Facades\Log;

class MessageHandler {

    private $whatsappService;
    private $googleSheetService;
    private $openIaService;
    private $appointmentState = [];
    private $assistantState = [];

    private $chatFlow;
    private $chat;

    public function __construct()
    {
        $this->whatsappService = new WhatsappService();
        $this->googleSheetService = new GoogleSheetService();
        $this->openIaService = new OpenAIService();
        $this->chatFlow = new ChatFlow();
        $this->chat = new Chat();
    }

    public function sendResponse($to, $message)
    {
        try{
            $this->whatsappService->sendMessage($to, $message);
        }catch (\Exception $e) {
            Log::error("Error sending message: " . $e->getMessage());
        }
        
    }

    public function handleIncomingMessage($message, $senderInfo)
    {
        Log::info("handleIncomingMessage -> message");
        Log::info($message);
        Log::info("handleIncomingMessage -> senderInfo");
        Log::info($senderInfo);

        Log::info("handleIncomingMessage -> getPhoneNumber");
        Log::info($this->getPhoneNumber($senderInfo));
        Log::info("handleIncomingMessage -> getMsjText");
        Log::info($this->getMsjText($message));

        $this->chat->create([
            'phone' => $this->getPhoneNumber($senderInfo),
            'mje' => $this->getMsjText($message),
            'status' => 'waiting'
        ]);

        
        $this->whatsappService->markAsRead($message['id']);
    }

}
