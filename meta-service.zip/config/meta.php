<?php

return [
    'api_uri' => env('WHATSAPP_API_URI', 'https://graph.facebook.com/v21.0/'),
    'whatsapp_business_account_id' => env('WHATSAPP_BUSINESS_ACCOUNT_ID', '514944728364882'),
    'access_token' => env('ACCESS_TOKEN', 'EAAPfMCZCyUFQBPDWqzoImvR8eTxIxQaTstRsZBZBzSGe5hlDUrp2XUZA2XVFLmAA5fuET29DvmDKB1oLCiLW1VIs4qqEHlLQZC88VhnYCxiGZAdOkXC652VEoq6s9Ji2N2aEuQIRZAIYlVVvvHKcZABOZAqZChQZALR92RQTeXaW0TUpNQMRQPZCHgWFoXOO5q7cZCByDe465jSjk3ZBzdZBJJiHXxcCKXnNkLkDt3qbbLBjaAF7AZDZD'),
    'separator' => env('SEPARATOR', '~'),
    'from_phone_number_id' => env('FROM_PHONE_NUMBER_ID', '500851596447481'),
    'verify_token' => env('VERIFY_TOKEN', 'edgardoponce'),
];
